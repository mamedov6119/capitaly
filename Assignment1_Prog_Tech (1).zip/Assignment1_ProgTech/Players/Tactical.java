package Players;
import Fields.Field;
public class Tactical extends Player {
  private final static String type_of_player = "Tactical";
  private int round = 1;
  public Tactical(String nickname){

    super(nickname, type_of_player);

}

   public void buy(Field field) {
    if(this.money_balance >= 1000 && round%2 == 1) {
      this.money_balance -= 1000;
      field.setOwner(this);
      properties_owned.add(field); 
      round++;
    }

   }


   public void build_a_house(Field field) {
    if (this.money_balance >= 4000 && round%2 == 1) {
      this.money_balance -= 4000;
      field.build_a_house();
      round++;
    }
   }


}
