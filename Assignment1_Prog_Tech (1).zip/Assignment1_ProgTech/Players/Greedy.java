package Players;
import Fields.Field;
import java.util.Properties;

public class Greedy extends Player {

  private final static String type_of_player = "Greedy";

   public Greedy(String nickname) {
     super(nickname,type_of_player);
   }

   public void buy(Field field) {
    if(this.money_balance >= 1000 ) {
      this.money_balance -= 1000;
      field.setOwner(this);
      properties_owned.add(field); 

    }

   }


   public void build_a_house(Field field) {
    if (this.money_balance >= 4000) {
      this.money_balance -= 4000;
      field.build_a_house();
    }
   }

}
