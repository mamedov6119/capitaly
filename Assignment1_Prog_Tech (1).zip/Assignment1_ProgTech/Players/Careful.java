package Players;
import Fields.Field;
public class Careful extends Player  {


  public Careful(String nickname){

    super(nickname, "Careful");

}


  public void buy(Field field) {
    if (this.money_balance >= 2000) {
      this.money_balance -= 1000;
      field.setOwner(this);
      properties_owned.add(field);
    }
  }




  public void build_a_house(Field field) {
    if(this.money_balance >= 8000) {
      this.money_balance -= 4000;
      field.build_a_house();
    }
  }
}






