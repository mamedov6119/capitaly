package Players;
import Fields.Field;
import java.util.ArrayList;

public class Player {
  protected String nickname;
  protected String type;
  protected int money_balance;
  protected ArrayList<Field> properties_owned;
  protected int cell; // position of the player

  public Player(String nickname, String type) {
    this.nickname = nickname;
    this.money_balance = 10000;
    this.type = type;
    properties_owned = new ArrayList<>();
    cell = -1;

  }


  public String getNickName() {
    return this.nickname;
  }


  public int getMoneyBalance() {
    return this.money_balance;
  }

  public String getTypePlayer() {
    return this.type;
  }

  public void setCell(int cell) {
    this.cell = cell;
  }

  public int getCell() {
    return this.cell;
  }

  public void transaction_to(int amount) {
    this.money_balance -= amount;
  }

  public void transaction_from(int amount) {
    this.money_balance += amount;
  }

  public void IncCell(int dice_rolled, int quan_fields)  {
    this.cell += dice_rolled;
    this.cell = this.cell % quan_fields; 
  }

  public boolean inGame() {
    if (this.money_balance >= 0) {
      return true;
    }
    return false;
  }



  public void fine(int amount) {
    this.money_balance -= amount;
  }

  public  void buy(Field f){}

    

  public void build_a_house(Field f){}



  @Override

  public String toString() {      
    int cnt = 0;
    for (int i = 0; i < properties_owned.size(); i++) {
        cnt++;
    }    
      return nickname +" | Type: "+type +" | Balance: " + money_balance +" | Fields Owned: "+ cnt + " (!)";
  }
}




