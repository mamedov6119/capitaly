package Fields;
import Players.Player;

public class Service extends Field {
  //  public Service(int amount) {
  //    super(amount);
  //  }

  //  public void action(Player p) {
  //    // Remove (this.amount) of money from player
  //    // transfer: => -amount
  //    p.transfer(this.amount);
  //  }


  private int fine;

  public Service(int fine) {
    super("Service");
    this.fine = fine;
  }


  public int getStepFine() {
    return this.fine;
  }


}
