package Fields;

import Players.Player;

public class Property extends Field {
  private Player player;
  private int num_of_house;
  
  public Property() {
    super("Property");
    this.player = null;
    this.num_of_house = 0;
  }


  public void setOwner(Player p) {
    this.player = p;
  }

  public Player getOwner(){
    return this.player;
 }


  public boolean is_owned() {
    if (this.player != null) {
      return true;
    }
    return false;
  }

  public boolean has_a_house() {
    if (this.num_of_house == 1) {
      return true;
    }
    return false;
  }


  public void build_a_house() {
    this.num_of_house = 1;
  }

  public void lose_a_field() {
    this.num_of_house = 0;
    this.player = null;
  }

}











// private int owner = -1;
//    private int buyRound = -1;
//    private int rentPrice = 500;
//    private boolean hasHouse = false;

//    public Property() {
//      super(1000);
//    }

//    public void action(Player p, int round) {
//      // Case "No owner"
//      if (this.owner == -1) {
//        boolean bought = p.fieldAction(this.amount); // try buying a house
//        if (bought) {
//          this.owner = p.getId();
//          this.buyRound = round;
//        }
//      }
//      // Case "Has owner"
//      else {
//        // Player is NOT an owner
//        if (this.owner != p.getId()) {
//          p.transfer(this.rentPrice);
//        }
//        // Player is an owner
//        else {
//          if (!this.hasHouse && this.buyRound > round) {
//            boolean built = p.fieldAction(4000); // try building a house
//            if (built) {
//              this.hasHouse = true;
//              this.rentPrice = 2000;
//            }
//          }
//        }
//      }
//    }
