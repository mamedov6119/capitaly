package Fields;
import Players.Player;
public abstract class Field {

  private final String field_name;


  public Field(String field_name) {
      this.field_name = field_name;
  }

  public String getFieldType(){
    return this.field_name;
  }

  public int getStepFine(){
    return 0;
  }

  public int getMoney(){
    return 0;
  }

  public boolean is_owned(){
    return false;
  }


  public void setOwner(Player p) {

  }

  public Player getOwner() {
    return new Player("NULL", "NULL");
  }

  public boolean has_a_house() {
    return false;
  }


  public void build_a_house() {
    
  }

  public void lose_a_field() {

  }






    //  private int amount;

  //  public Field(int amount) {
  //    this.amount = amount;
  //  }

  //  public void action(Player p) {} // override by child;
}
