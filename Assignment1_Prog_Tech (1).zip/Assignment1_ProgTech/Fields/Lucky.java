package Fields;

public class Lucky extends Field {

  private int money;


  public Lucky(int money) {
      super("Lucky");
      this.money = money;
  }

  public int getMoney() {
    return this.money;
  }
  //  public void action(Player p) {
  //    // Add (this.amount) of money to player
  //    // transfer: -1*(-amount) => +amount
  //    p.transfer(-1 * this.amount);
  //  }
}
