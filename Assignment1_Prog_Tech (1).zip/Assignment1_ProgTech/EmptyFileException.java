public class EmptyFileException extends Exception {
    
     
        EmptyFileException() {
        }

    
}
