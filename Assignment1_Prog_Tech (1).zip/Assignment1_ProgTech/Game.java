import java.util.ArrayList;

import Fields.Field;
import Fields.Lucky;
import Fields.Property;
import Players.Careful;
import Players.Greedy;
import Players.Player;
import Players.Tactical;
import Fields.Service;

import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.io.FileNotFoundException;
public class Game {
  public int rounds;

  private ArrayList<Field> fields;

  private ArrayList<Player> players;

  private ArrayList<Integer> dice;

  public int players_in_game() {
    int cnt = 0;
    for (int i = 0; i < players.size(); i++) {
      cnt += (players.get(i).inGame() ? 1 : 0);
    }
    return cnt;
  }

  private int quan_players;
  private int quan_fields;

  public Game(String fname, int rounds) throws Exception {
    this.fields = new ArrayList<Field>();
    this.players = new ArrayList<Player>();
    this.dice = new ArrayList<Integer>();
    this.read_file(fname);
    this.rounds = rounds;

    
  }

  public void read_file(String fname) throws IOException, EmptyFileException {
    try {
      if (new File(fname).length() == 0) {
        throw new EmptyFileException(); 
      }
    } catch (EmptyFileException e) {
      System.out.println("Empty File Exception!");
    }
    Scanner sc = new Scanner(new File(fname));
    
    
    
    try {
      String check = sc.nextLine();
      quan_fields = Integer.parseInt(check);
    } catch (Exception e) {
      System.out.println("File is not fully complete or has formatiing errors!");
    }
    
    for (int i = 0; i < quan_fields; i++) {

        String[] data = sc.nextLine().split(" ");
        String current_elem = data[0];
        

        if (current_elem.equals("property")) {
          fields.add(new Property());
        } else if (current_elem.equals("luckyfield")) {
          fields.add(new Lucky(Integer.parseInt(data[1])));
        } else if (current_elem.equals("service")) {
          fields.add(new Service(Integer.parseInt(data[1])));
        } else
          System.out.println("Unknown element...");
        
      
    }

    // quan_players = Integer.parseInt(sc.nextLine());
    

    try {
      String check = sc.nextLine();
      quan_players = Integer.parseInt(check);
    } catch (Exception e) {
      System.out.println("File is not fully complete or has formatiing errors!");
    }
    
    
    for (int i = 0; i < quan_players; i++) {

        String data[] = sc.nextLine().split(" ");
        String nickname = data[0];
        String typeOfPlayer = data[1];
   

        if (typeOfPlayer.equals("Greedy")) {
          players.add(new Greedy(nickname));
        } else if (typeOfPlayer.equals("Careful")) {
          players.add(new Careful(nickname));
        } else if (typeOfPlayer.equals("Tactical")) {
          players.add(new Tactical(nickname));
        }


    

      }
    while (sc.hasNext()) {
      dice.add(Integer.parseInt(sc.next()));
    }

  }


  public void start() {
    int dice_rol = 0;
    int counter = 0;
    while (players_in_game() > 1) {
      Output(players, counter);
      counter++;
      for (int i = 0; i < players.size(); i++) {
        int num_steps = dice.get(dice_rol);
        if (players.get(i).inGame()) {
          players.get(i).IncCell(num_steps, quan_fields);
          Field f = fields.get(players.get(i).getCell());

          switch (f.getFieldType()) {
            case "Lucky":
              players.get(i).luckyPayOut(f.getMoney());
              break;
            case "Property":
              if (f.is_owned()) {
                if (f.getOwner().equals(players.get(i))) {
                  if (!f.has_a_house()) {
                    players.get(i).build_a_house(f);
                  }
                } else {
                  if (!f.has_a_house()) {
                    if (players.get(i).getMoneyBalance() >= 500) {
                      players.get(i).transaction_to(500);
                      f.getOwner().transaction_from(500);
                    }
                     else {
                      if (players.get(i).getMoneyBalance() >= 0) {
                        f.getOwner().transaction_from(players.get(i).getMoneyBalance());
                      }
                      players.get(i).transaction_to(500);
                    
                    }
                  } else {
                    if (players.get(i).getMoneyBalance() >= 2000) {
                      players.get(i).transaction_to(2000);
                      f.getOwner().transaction_from(2000);
                    } else {
                      if (players.get(i).getMoneyBalance() >= 0) {
                        f.getOwner().transaction_from(players.get(i).getMoneyBalance());
                      }
                      players.get(i).transaction_to(2000);
                    }
                  }
                }
                 
              } else {
                players.get(i).buy(f);
              }
              break;
            case "Service":
              players.get(i).fine(f.getStepFine());
              break;

            default:
              break;

          }
          dice_rol += 1;

        } 
          
        

      }
    }

    
  }
  



  public void Output(ArrayList<Player> players, int counter) {
    if (counter < this.rounds) {
      System.out.println("Round " + (counter+1));  
      
    for (int i = 0; i < players.size(); i++) {
      if (players.get(i).inGame()) {   
        System.out.println("(!) " + players.get(i));

      }
    }
    System.out.println('\n');
  }
  }

}
