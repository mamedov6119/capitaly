

class Main {
   public static void main(String[] args) {
      try {
         int rounds = Integer.parseInt(args[0]);
         
         // Game game = new Game("test0.txt", rounds); // Fully completed 
         // Game game = new Game("test1.txt", rounds); // Fully completed
         // Game game = new Game("test2.txt", rounds); // Empty file
         // Game game = new Game("test3.txt", rounds); // Not fully completed
         Game game = new Game("test4.txt", rounds); // Not fully completed

         game.start();
      } catch (Exception e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
      }


   }
}
